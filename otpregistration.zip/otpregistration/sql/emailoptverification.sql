-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 18, 2023 at 07:16 PM
-- Server version: 5.7.41-0ubuntu0.18.04.1
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emailoptverification`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `userName` varchar(150) DEFAULT NULL,
  `emailId` varchar(150) DEFAULT NULL,
  `ContactNumber` bigint(12) DEFAULT NULL,
  `userPassword` varchar(200) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emailOtp` int(6) DEFAULT NULL,
  `isEmailVerify` int(1) DEFAULT NULL,
  `lastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `userName`, `emailId`, `ContactNumber`, `userPassword`, `regDate`, `emailOtp`, `isEmailVerify`, `lastUpdationDate`) VALUES
(2, 'Anuk', 'anuj@gmail.com', 1234567890, '5c428d8875d2948607f3e3fe134d71b4', '2021-09-19 03:39:22', 108303, 1, '2021-09-19 04:52:00'),
(3, 'Test User', 'test@gmail.com', 1234567890, 'f925916e2754e5e03f75dd58a5733251', '2021-09-19 04:51:46', 867056, 1, '2021-09-19 05:00:10'),
(5, 'Amit', 'amit@gmail.com', 234567890, '202cb962ac59075b964b07152d234b70', '2021-09-19 05:01:25', 247589, 1, '2021-09-19 05:04:54'),
(15, 'tests', 'rashmi.v@msp-group.co.uk', 9876543210, 'a624e682e263c8ad6b380a6958a86a1b', '2023-04-18 13:36:27', 184249, 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
