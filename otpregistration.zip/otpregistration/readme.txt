How to run the User Registration With Email OTP Verification Using PHP

1.Download the zip file

2.Extract the file and copy emailotpverification folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name regdb

6.Import emailoptverification.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/emailotpverification


